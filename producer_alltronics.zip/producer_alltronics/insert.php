<?php

include('dbconnect.php');

$producer_id = $_POST['producer_id'];

$producer_name = $_POST['producer_name'];

$producer_address = $_POST['producer_address'];

$producer_mobile = $_POST['producer_mobile'];

$producer_mailid = $_POST['producer_mailid'];


//create query


$query = "INSERT INTO producer (producer_id , producer_name , producer_address , producer_mobile , producer_mailid) VALUES('$producer_id' , '$producer_name' , '$producer_address' , '$producer_mobile' , '$producer_mailid')";

if(mysqli_query($conn ,$query)){
	
header("Location:form.php");
}

else{
	
	echo "Error In Query" .mysqli_error($conn);
}
mysqli_close($conn);


?>
