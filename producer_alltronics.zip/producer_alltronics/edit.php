<?php

include('dbconnect.php');

$id=$_POST['id'];

$producer_id=$_POST['producer_id'];

$producer_name=$_POST['producer_name'];

$producer_address=$_POST['producer_address'];

$producer_mobile=$_POST['producer_mobile'];

$producer_mailid=$_POST['producer_mailid'];

$query="UPDATE producer SET producer_id='$producer_id',producer_name='$producer_name',producer_address='$producer_address',producer_mobile='$producer_mobile',producer_mailid='$producer_mailid  WHERE id='$id'";


if(mysqli_query($conn,$query)){
	
	header("Location:form.php");
	
}

else{
	echo "Error in query";
}

mysqli_close($conn);
?>