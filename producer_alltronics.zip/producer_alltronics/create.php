<?php
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$producer_id = $producer_name = $producer_address = $producer_mobile = $producer_mailid = "";
$producer_id_err = $producer_name_err = $producer_address_err = $producer_mobile_err = $producer_mailid_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate producer_id
    $input_producer_id = trim($_POST['producer_id']);
    if(empty($input_producer_id)){
        $producer_id_err = "Please enter the producer_id.";     
    } else{
        $producer_id = $input_producer_id;
    }
    // Validate name
    $input_producer_name = trim($_POST["producer_name"]);
    if(empty($input_producer_name)){
        $producer_name_err = "Please enter producer name.";
    } elseif(!filter_var(trim($_POST["producer_name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $producer_name_err = 'Please enter a valid name.';
    } else{
        $producer_name = $input_producer_name;
    }
    
    // Validate producer_address
    $input_producer_address = trim($_POST["producer_address"]);
    if(empty($input_producer_address)){
        $producer_address_err = 'Please enter producer_address.';     
    } else{
        $producer_address = $input_producer_address;
    }
    // Validate producer_mobile
    $input_producer_mobile = trim($_POST['producer_mobile']);
    if(empty($input_producer_mobile)){
        $producer_mobile_err = "Please enter the valid producer_mobilenumber.";     
    } else{
        $producer_mobile = $input_producer_mobile;
    }
    // Validate producer_mailid
    $input_producer_mailid = trim($_POST['producer_mailid']);
    if(empty($input_producer_mailid)){
        $producer_mailid_err = "Please enter the valid mail-id.";     
    } else{
        $producer_mailid = $input_producer_mailid;
    }
    // Check input errors before inserting in database
    if(empty($producer_id_err) && empty($producer_name_err) && empty($producer_address_err) && empty($producer_mobile_err) && empty($producer_mailid)){
        // Prepare an insert statement
        $sql = "INSERT INTO producer (producer_id, producer_name, producer_address, producer_mobile, producer_mailid) VALUES (?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_producer_id, $param_producer_name, $param_producer_address, $param_producer_mobile, $param_producer_mailid);
            
            // Set parameters
            $param_producer_id = $producer_id;
            $param_producer_name = $producer_name;
            $param_producer_address = $producer_address;
            $param_producer_mobile = $producer_mobile;
            $param_producer_mailid = $producer_mailid;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add subjects record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($producer_id_err)) ? 'has-error' : ''; ?>">
                            <label>Producer Id</label>
                            <input type="number" name="producer_id" class="form-control" value="<?php echo $producer_id; ?>">
                            <span class="help-block"><?php echo $producer_id_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($producer_name_err)) ? 'has-error' : ''; ?>">
                            <label>Producer Name</label>
                            <input type="text" name="producer_name" class="form-control" value="<?php echo $producer_name; ?>">
                            <span class="help-block"><?php echo $producer_name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($producer_address_err)) ? 'has-error' : ''; ?>">
                            <label>Producer address</label>
                            <input type="text" name="producer_address" class="form-control" value="<?php echo $producer_address; ?>">
                            <span class="help-block"><?php echo $producer_address_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($producer_mobile_err)) ? 'has-error' : ''; ?>">
                            <label>Producer mobile number</label>
                            <input type="number" name="producer_mobile" class="form-control" value="<?php echo $producer_mobile; ?>">
                            <span class="help-block"><?php echo $producer_mobile_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($producer_mailid_err)) ? 'has-error' : ''; ?>">
                            <label>Producer mailid</label>
                            <input type="email" name="producer_mailid" class="form-control" value="<?php echo $producer_mailid; ?>">
                            <span class="help-block"><?php echo $producer_mailid_err;?></span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>