<?php

$host = "localhost";

$user = "root";

$password = "";

$dbname = "distributor";


$conn = mysqli_connect($host , $user , $password , $dbname);

if(!$conn){
	
	die("error in connection");
}




?>