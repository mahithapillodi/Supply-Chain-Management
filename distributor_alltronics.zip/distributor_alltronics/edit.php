<?php

include('dbconnect.php');

$id=$_POST['id'];

$distributor_name=$_POST['distributor_name'];

$distributor_address=$_POST['distributor-address'];

$distributor_mobileno=$_POST['distributor_mobileno'];

$distributor_mailid=$_POST['distributor_mailid'];

$distributor_id=$_POST['distributor_id'];

$query="UPDATE distributor SET distributor_name='$distributor_name',distributor_address='$distributor_address',distributor_mobileno='$distributor_mobileno',distributor_mailid='$distributor_mailid',distributor_id='$distributor_id' WHERE id='$id'";


if(mysqli_query($conn,$query)){
	
	header("Location:form.php");
	
}

else{
	echo "Error in query";
}

mysqli_close($conn);
?>