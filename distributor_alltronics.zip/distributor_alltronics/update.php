<?php
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$distributor_name = $distributor_address = $distributor_mobileno = $distributor_mailid = $distributor_id = "";
$distributor_name_err = $distributor_address_err = $distributor_mobileno_err = $distributor_mailid_err = $distributor_id_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate distributor_name
    $input_distributor_name = trim($_POST["distributor_name"]);
    if(empty($input_distributor_name)){
        $distributor_name_err = "Please enter  distributor name.";
    } elseif(!filter_var(trim($_POST["distributor_name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $distributor_name_err = 'Please enter a valid  distributor name.';
    } else{
        $distributor_name = $input_distributor_name;
    }
    
    // Validate distributor_address 
    $input_distributor_address = trim($_POST["distributor_address"]);
    if(empty($input_distributor_address)){
        $distributor_address_err = 'Please enter an distributor_address.';     
    } else{
        $distributor_address = $input_distributor_address;
    }
    
    // Validate distributor_mobileno
    $input_distributor_mobileno = trim($_POST["distributor_mobileno"]);
    if(empty($input_distributor_mobileno)){
        $distributor_mobileno_err = "Please enter the description.";     
    } else{
        $distributor_mobileno = $input_distributor_mobileno;
    }
    // Validate distributor_mailid
    $input_distributor_mailid = trim($_POST["distributor_mailid"]);
    if(empty($input_distributor_mailid)){
        $distributor_mailid_err = "Please enter the distributor_mailid.";     
    } else{
        $distributor_mailid = $input_distributor_mailid;
    }
     // Validate distributor_id
       $input_distributor_id = trim($_POST["distributor_id"]);
    if(empty($input_distributor_id)){
        $distributor_id_err = "Please enter the distributor_id.";     
    } else{
        $distributor_id = $input_distributor_id;
    }
    // Check input errors before inserting in database
    if(empty($distributor_name_err) && empty($distributor_address_err)  && empty($distributor_mobileno_err) && empty($distributor_mailid_err) && empty($distributor_id_err)){
        // Prepare an insert statement
        $sql = "UPDATE distributor SET distributor_name=?, distributor_address=?, distributor_mobileno=?, distributor_mailid=?, distributor_id WHERE id=?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssi", $param_distributor_name, $param_distributor_address, $param_distributor_mobileno, $param_distributor_mailid, $param_distributor_id, $param_id);
            
            // Set parameters
            $param_distributor_name = $distributor_name;
            $param_distributor_address = $distributor_address;
			$param_ditributor_mobileno = $distributor_mobileno;
            $param_distributor_mailid = $distributor_mailid;
            $param_distributor_id= $distributor_id;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM distributor WHERE id = ?";
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set
                    contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $distributor_name = $row["distributor_name"];
                    $distributor_address = $row["distributor_address"];
					$distributor_mobileno = $row["distributor_mobileno"];
                    $distributor_mailid = $row["distributor_mailid"];
                    $distributor_id=$row["distributor_id"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($link);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Update Record</h2>
                    </div>
                    <p>Please edit the input values and submit to update the record.</p>
                    <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="form-group <?php echo (!empty($distributor_name_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_Name</label>
                            <input type="text" name="distributor_name" class="form-control" value="<?php echo $distributor_name; ?>">
                            <span class="help-block"><?php echo $distributor_name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($distributor_address_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_address</label>
                            <input type="text" name="distributor_address" class="form-control" value="<?php echo $distributor_address; ?>">
                            <span class="help-block"><?php echo $distributor_address_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($distributor_mobileno_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_mobileno</label>
                            <input type="text" name="distributor_mobileno" class="form-control" value="<?php echo $distributor_mobileno; ?>">
                            <span class="help-block"><?php echo $distributor_mobileno_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($distributor_mailid_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_mailid</label>
                            <input type="text" name="distributor_mailid" class="form-control" value="<?php echo $distributor_mailid; ?>">
                            <span class="help-block"><?php echo $distributor_mailid_err;?></span>
                        </div>
                           <div class="form-group <?php echo (!empty($distributor_id_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_id</label>
                            <input type="text" name="distributor_id" class="form-control" value="<?php echo $distributor_id; ?>">
                            <span class="help-block"><?php echo $distributor_id_err;?></span>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>