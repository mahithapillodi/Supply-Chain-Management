<?php

include('dbconnect.php');



$distributor_name = $_POST['distributor_name'];

$distributor_address = $_POST['distributor_address'];

$distributor_mobileno = $_POST['distributor_mobileno'];

$distributor_mailid = $_POST['distributor_mailid'];

$distributor_id = $_POST['distributor_id'];

//create query


$query = "INSERT INTO distributor (distributor_name , distributor_address , distributor_mobileno , distributor_mailid , distributor_id) VALUES('$distributor_name' , '$distributor_address' , '$distributor_mobileno' , '$distributor_mailid' '$distributor_id')";

if(mysqli_query($conn ,$query)){
	
header("Location:form.php");
}

else{
	
	echo "Error In Query" .mysqli_error($conn);
}
mysqli_close($conn);


?>
