<?php
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$distributor_name = $distributor_address = $distributor_mobileno = $distributor_mailid = $distributor_id ="";
$distributor_name_err = $distributor_address_err = $distributor_mobileno_err = $distributor_mailid_err = $distributor_id_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate distributor_name
    $input_distributor_name = trim($_POST["distributor_name"]);
    if(empty($input_distributor_name)){
        $distributor_name_err = "Please enter a name.";
    } elseif(!filter_var(trim($_POST["distributor_name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $distributor_name_err = 'Please enter a valid name.';
    } else{
        $distributor_name = $input_distributor_name;
    }
    
    // Validate distributor_address
    $input_distributor_address = trim($_POST["distributor-address"]);
    if(empty($input_distributor_address)){
        $distributor_address_err = 'Please enter distributor_address';     
    } else{
        $distributor_address = $input_distributor_address;
    }
    
    // Validate distributor_mobileno
    $input_distributor_mobileno = trim($_POST['distributor_mobileno']);
    if(empty($input_distributor_mobileno)){
        $distributor_mobileno_err = "Please enter the distributor_mobileno.";     
    } else{
        $distributor_mobileno = $input_distributor_mobileno;
    }
	
	 // Validate distributor_mailid
    $input_distributor_mailid = trim($_POST["distributor_mailid"]);
    if(empty($input_distributor_mailid)){
        $distributor_mailid_err = "Please enter the distributor_mailid";     
    } else{
        $distributor_mailid = $input_distributor_mailid;
    }
         //validate distributor_id
    $input_distributor_mobile = trim($_POST['distributor_id']);
    if(empty($input_distributor_id)){
        $distributor_id_err = "Please enter the distributor_id.";     
    } else{
        $distributor_id = $input_distributor_id;
    }
    
    // Check input errors before inserting in database
    if(empty($distributor_name_err) && empty($distributor_address_err) &&  empty($distributor_mobileno_err) && empty($distributor_mailid_err) && empty($distributor_id_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO distributor (distributor_name,distributor_address,distributor_mobileno,distributor_mailid,distributor_id) VALUES (?, ?, ?, ?,?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_distributor_name, $param_distributor_address, $param_distributor_mobileno, $param_distributor_mailid, $param_distributor_id);
            
            // Set parameters
            $param_distributor_name = $distributor_name;
            $param_distributor_address = $distributor_address;
            $param_distributor_mobileno = $distribotor_mobileno;
            $param_distributor_mailid = $distributor_mailid;
            $param_distributor_id = $distributor_id;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                     </div>
                    <p>Please fill this form and submit to add subjects record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($distributor_name_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_name</label>
                            <input type="text" name="distributor_name" class="form-control" value="<?php echo $distributor_name; ?>">
                            <span class="help-block"><?php echo $distributor_name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($distributor_address_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_address</label>
                            <input type="text" name="distributor_address" class="form-control" value="<?php echo $distributor_address; ?>">
                            <span class="help-block"><?php echo $distributor_address_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($distributor_mobileno_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_mobileno</label>
                            <input tyoe="text"  name="distributor_mobileno" class="form-control" value="<?php echo $distributor_mobileno; ?>">
                            <span class="help-block"><?php echo $distributor_mobileno_err;?></span>
                        </div>
						<div class="form-group <?php echo (!empty($distributor_mailid_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_mailid</label>
                            <input type="text" name="distributor_mailid" class="form-control" value="<?php echo $distributor_mailid; ?>">
                            <span class="help-block"><?php echo $distributor_malid_err;?></span>
                        </div>
                          <div class="form-group <?php echo (!empty($distributor_id_err)) ? 'has-error' : ''; ?>">
                            <label>distributor_id</label>
                            <input tyoe="text"  name="distributor_id" class="form-control" value="<?php echo $distributor_id; ?>">
                            <span class="help-block"><?php echo $distributor_id_err;?></span>
                        </div>
                          <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>