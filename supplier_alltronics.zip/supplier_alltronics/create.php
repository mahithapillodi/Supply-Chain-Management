<?php
// Include config file
require_once 'config.php';
 
// Define variables and initialize with empty values
$supplier_id = $supplier_name = $supplier_address = $supplier_mobile = $supplier_mailid = "";
$supplier_id_err = $supplier_name_err = $supplier_address_err = $supplier_mobile_err = $supplier_mailid_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate supplier_id
    $input_supplier_id = trim($_POST['supplier_id']);
    if(empty($input_supplier_id)){
        $supplier_id_err = "Please enter the supplier_id.";     
    } else{
        $supplier_id = $input_supplier_id;
    }
    // Validate name
    $input_supplier_name = trim($_POST["supplier_name"]);
    if(empty($input_supplier_name)){
        $supplier_name_err = "Please enter supplier name.";
    } elseif(!filter_var(trim($_POST["supplier_name"]), FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z'-.\s ]+$/")))){
        $supplier_name_err = 'Please enter a valid name.';
    } else{
        $supplier_name = $input_supplier_name;
    }
    
    // Validate supplier_address
    $input_supplier_address = trim($_POST["supplier_address"]);
    if(empty($input_supplier_address)){
        $supplier_address_err = 'Please enter supplier_address.';     
    } else{
        $supplier_address = $input_supplier_address;
    }
    // Validate supplier_mobile
    $input_supplier_mobile = trim($_POST['supplier_mobile']);
    if(empty($input_supplier_mobile)){
        $supplier_mobile_err = "Please enter the valid supplier_mobilenumber.";     
    } else{
        $supplier_mobile = $input_supplier_mobile;
    }
    // Validate supplier_mailid
    $input_supplier_mailid = trim($_POST['supplier_mailid']);
    if(empty($input_supplier_mailid)){
        $supplier_mailid_err = "Please enter the valid mail-id.";     
    } else{
        $supplier_mailid = $input_supplier_mailid;
    }
    // Check input errors before inserting in database
    if(empty($supplier_id_err) && empty($supplier_name_err) && empty($supplier_address_err) && empty($supplier_mobile_err) && empty($supplier_mailid)){
        // Prepare an insert statement
        $sql = "INSERT INTO supplier (supplier_id, supplier_name, supplier_address, supplier_mobile, supplier_mailid) VALUES (?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_supplier_id, $param_supplier_name, $param_supplier_address, $param_supplier_mobile, $param_supplier_mailid);
            
            // Set parameters
            $param_supplier_id = $supplier_id;
            $param_supplier_name = $supplier_name;
            $param_supplier_address = $supplier_address;
            $param_supplier_mobile = $supplier_mobile;
            $param_supplier_mailid = $supplier_mailid;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Create Record</h2>
                    </div>
                    <p>Please fill this form and submit to add subjects record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($supplier_id_err)) ? 'has-error' : ''; ?>">
                            <label>Supplier Id</label>
                            <input type="number" name="supplier_id" class="form-control" value="<?php echo $supplier_id; ?>">
                            <span class="help-block"><?php echo $supplier_id_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($supplier_name_err)) ? 'has-error' : ''; ?>">
                            <label>Supplier Name</label>
                            <input type="text" name="supplier_name" class="form-control" value="<?php echo $supplier_name; ?>">
                            <span class="help-block"><?php echo $supplier_name_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($supplier_address_err)) ? 'has-error' : ''; ?>">
                            <label>Supplier address</label>
                            <input type="text" name="supplier_address" class="form-control" value="<?php echo $supplier_address; ?>">
                            <span class="help-block"><?php echo $supplier_address_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($supplier_mobile_err)) ? 'has-error' : ''; ?>">
                            <label>Supplier mobile number</label>
                            <input type="number" name="supplier_mobile" class="form-control" value="<?php echo $supplier_mobile; ?>">
                            <span class="help-block"><?php echo $supplier_mobile_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($supplier_mailid_err)) ? 'has-error' : ''; ?>">
                            <label>Supplier mailid</label>
                            <input type="email" name="supplier_mailid" class="form-control" value="<?php echo $supplier_mailid; ?>">
                            <span class="help-block"><?php echo $supplier_mailid_err;?></span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>