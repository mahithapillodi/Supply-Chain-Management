<?php
	require_once("functions/functions.php");
?>
<?php
	get_header();
?>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        
<?php
	get_sidebar();
?>
<?php
	get_navbar();
?>
        

        <!-- page content -->
        <div class="right_col" role="main">
          <!--Paste Content Below-->
		  
		  <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Fixed Sidebar <small> Just add class <strong>menu_fixed</strong></small></h3>
              </div>
            </div>
          </div>
		  
          <!--Paste Content Above-->
        </div>
        <!-- /page content -->
<?php
	get_footer();
?>
	
  </body>
</html>
