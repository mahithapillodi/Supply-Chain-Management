<?php

include('dbconnect.php');

$id=$_POST['id'];

$supplier_id=$_POST['supplier_id'];

$supplier_name=$_POST['supplier_name'];

$supplier_address=$_POST['supplier_address'];

$supplier_mobile=$_POST['supplier_mobile'];

$supplier_mailid=$_POST['supplier_mailid'];

$query="UPDATE supplier SET supplier_id='$supplier_id',supplier_name='$supplier_name',supplier_address='$supplier_address',supplier_mobile='$supplier_mobile',supplier_mailid='$supplier_mailid  WHERE id='$id'";


if(mysqli_query($conn,$query)){
	
	header("Location:form.php");
	
}

else{
	echo "Error in query";
}

mysqli_close($conn);
?>