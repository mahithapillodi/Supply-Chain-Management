<?php

include('dbconnect.php');

$supplier_id = $_POST['supplier_id'];

$supplier_name = $_POST['supplier_name'];

$supplier_address = $_POST['supplier_address'];

$supplier_mobile = $_POST['supplier_mobile'];

$supplier_mailid = $_POST['supplier_mailid'];


//create query


$query = "INSERT INTO supplier (supplier_id , supplier_name , supplier_address , supplier_mobile , supplier_mailid) VALUES('$supplier_id' , '$supplier_name' , '$supplier_address' , '$supplier_mobile' , '$supplier_mailid')";

if(mysqli_query($conn ,$query)){
	
header("Location:form.php");
}

else{
	
	echo "Error In Query" .mysqli_error($conn);
}
mysqli_close($conn);


?>
