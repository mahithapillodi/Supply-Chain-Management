<?php

$host = "localhost";

$user = "root";

$password = "";

$dbname = "customer";


$conn = mysqli_connect($host , $user , $password , $dbname);

if(!$conn){
	
	die("error in connection");
}




?>